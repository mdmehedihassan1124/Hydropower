Title  
GloHydroRes - a global dataset combining open-source hydropower plant and reservoir data

Description
Analyzing the impacts of drought and climate change on hydropower requires detailed data not only on hydropower attributes such as plant type, head, and installed capacity, but also on reservoir characteristics like area, depth, and volume. Current open-source hydropower datasets typically lack information on reservoirs, while reservoir datasets often omit hydropower details. GloHydroRes is a global dataset that integrates open-source hydropower and reservoir data, offering 29 attributes, including key information such as installed capacity, plant type, dam height, reservoir depth, area, volume, and river name. Overall, GloHydroRes provides data on 7,775 hydropower plants across 128 countries.

Author
Jignesh Shah, Jing Hu, Oreane Edelenbosch, Michelle T.H. van Vliet

Institution
Department of Physical Geography, Utrecht University, PO Box 80.115, 3508, TC, Utrecht, the Netherlands
Copernicus Institute of Sustainable Development, Utrecht University, PO Box 80.115, 3508, TC, Utrecht, the Netherlands

File Structure

1. GloHydroRes_vs1.xlsx : This file contains information regarding hydropower plants in GloHydroRes.
	1. File contains four worksheets : 
		a) "Summary" : Brief overview of GlHydroRes
		b) "Acronyms" : Abbrevation used
		c) "Field Description": Detail information about attributes collected
		d) "Data" : Actual data 

2. GloHydroRes_vs1.csv : The core dataset dervied from the "Data" worksheet.


3. IBT_GloHydroRes_Hydropower_Combined.xlsx: This file contains attributes related to Inter-Basin Transfer (IBT) projects mapped to hydropower in GloHydroRes
	1. File contains four worksheets : 
		a) "Summary" : Brief overview of GlHydroRes
		b) "Acronyms" : Abbrevation used
		c) "Field Description": Detail information about attributes collected
		d) "Data" : Actual data 

4. IBT_GloHydroRes_Hydropower_Combined.csv : The core dataset dervied from the "Data" worksheet.



Attributes 

1. GloHydroRes_vs1 : 
	1) ID: Unique ID
	2) country: Country where plant located
	3) name: plant name
	4) capacity_mw:	Nameplate capacity of hydropower plant [MW]
	5) plant_lat: Latitude of hydropower plant (WGS) [Degree Decimal]
	6) plant_lon: Longitude of hydropower plant (WGS) [Degree Decimal]
	7) plant_type: Type of hydropower plant	[ROR/STO/PS/NA]
	8) plant_type_source: Source which provided plant type information
	9) year: Power plant first started operation and if not available then commissioned year 
	10) plant_source: Source (dataset) which provide hydropower plant attributes.
	11) plant_source_id: "Unqiue ID of the source dataset for hydropower plant information. Following column of each dataset was used as unique id: "gppd_idnr" in WRI, "ID" in RePP, "id" in JRC and "eha_ptid" in EHA. 			     		     Not applicable if information collected during google search."
	12) dam_name: Name of dam 
	13) dam_height_m: Height of dam [Meters]
	14) dam_height_source: Source which provided dam height 
	15) res_name: Name of reservoir
	16) res_dam_source: Source which provided dam/reservoir geolocation. If source is not GranD, GeoDAR or	HydroLAKES then dam/reservoir geolocation may be available in man_dam_lat and man_dam_lon.
	17) res_dam_source_id:	Unique ID of the source dataset which reservoir linked to corresponding hydropower. Following columns were used as unique id: "grand_id" in GranD, "id_v11" in GeoDAR and "Hylak_id" in HydroLakes.
				Not applicable if collected from Google Search	Engine, Clean Development Mechanism document or other sources.
	18) man_dam_lat: Latitude coordinate of dam (WGS84) with manual search [Degree Decimal]
	19) man_dam_lon: Longitude coordinate of dam (WGS84) with manual search [Degree Decimal]
	20) river: Name of river
	21) head_m: Reported head [Meters]
	22) head_source: Source which provided head information
	23) res_avg_depth_m: Reservoir depth [Meters]
	24) res_area_km2: Reservoir area [Square kilometer (km2)]
	25) res_vol_km3: Reservoir volume [Cubic kilometer (km3)]	
	26) res_attr_source: Name of source which provided reservoir volume/area/depth information
	27) res_attr_id: Unique ID of the source dataset which provided reservoir attributes (volume, area and depth). Following columns were used as unique id: "grand_id" in GranD and "Hylak_id" in HydroLakes.
			 Not applicable if collected from Google Search	Engine, Clean Development Mechanism document or other sources.
	28) hydrolakes_id: HydroLakes ID
	29) final_comments: Final comments

	
2. IBT_GloHydroRes_Hydropower_Combined :
	1) glohydrores_id: Unique ID of GloHydroRes dataset
	2) hybas_id: Unique ID of basin from HydroBasin
	3) project_name: Name of IBT project
	4) ibt_source: Source of IBT data
	5) ibt_id: Unique ID of the source dataset. Following columns were used as unique ID: "Link ID" : Siddik et al. (2023) and "ID" : Global Inter Basin Hydrological Transfer Database (Lammers et al. 2022)
	6) ibt_flow_direction: Inflow : reservoir receives water from IBT project, Outflow: reservoir supply water to IBT project, Inflow/Outflow: Hydropower plant at intermediate location, Indirect : Hydropower upstream/downstream,						indirectly impacting IBT
	7) ibt_from: Location where the IBT project originates
	8) ibt_to: Location where the IBT project terminates
	9) ibt_status: Status of IBT project : Completed, Under Construction or Proposed
	10) ibt_startyear: Start year of IBT project
	11) ibt_minflow: Minimum flow in the IBT project [Cubic meter per day (m3/day)]
	12) ibt_maxflow: Maximum flow in the IBT project [Cubic meter per day (m3/day)]
	13) ibt_meanflow: Mean flow in the IBT project [Cubic meter per day (m3/day)]
	14) ibt_lengthoftransfer: Total length of trasnfer [Kilometer (km)]
	15) ibt_link: Commented about how hydropwer/reservoir uses IBT project
	16) ibt_comment: IBT regarding comment
	